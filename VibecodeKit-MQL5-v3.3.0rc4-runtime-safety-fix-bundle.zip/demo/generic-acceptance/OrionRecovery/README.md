# OrionRecovery

Canonical IR hash: `3fc409373ebdfc2af01f98d86c67033d7344cef1961f47e6fa1e677be8d24ba0`.

Status: **SOURCE-COMPLETE / NATIVE EVIDENCE PENDING**. MetaEditor compile and MT5 Strategy Tester evidence are mandatory before release.
